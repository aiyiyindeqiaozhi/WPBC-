```python
#引用约定
import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt
```


```python
#数据导入
data=pd.read_csv('data_2.csv')
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>outcome</th>
      <th>time</th>
      <th>radius_mean</th>
      <th>texture_mean</th>
      <th>perimeter_mean</th>
      <th>area_mean</th>
      <th>smoothness_mean</th>
      <th>compactness_mean</th>
      <th>concavity_mean</th>
      <th>...</th>
      <th>perimeter_worst</th>
      <th>area_worst</th>
      <th>smoothness_worst</th>
      <th>compactness_worst</th>
      <th>concavity_worst</th>
      <th>concave points_worst</th>
      <th>symmetry_worst</th>
      <th>fractal_dimension_worst</th>
      <th>diameter of the excised tumor in centimeters</th>
      <th>Lymph node status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>119513</td>
      <td>N</td>
      <td>31</td>
      <td>18.02</td>
      <td>27.600000</td>
      <td>117.50</td>
      <td>1013.0</td>
      <td>0.094890</td>
      <td>0.103600</td>
      <td>0.1086</td>
      <td>...</td>
      <td>139.70</td>
      <td>1436.0</td>
      <td>0.119500</td>
      <td>0.192600</td>
      <td>0.3140</td>
      <td>0.1170</td>
      <td>0.267700</td>
      <td>0.08113</td>
      <td>5.0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8423</td>
      <td>N</td>
      <td>61</td>
      <td>17.99</td>
      <td>22.300979</td>
      <td>122.80</td>
      <td>1001.0</td>
      <td>0.118400</td>
      <td>0.142642</td>
      <td>0.3001</td>
      <td>...</td>
      <td>184.60</td>
      <td>2019.0</td>
      <td>0.162200</td>
      <td>0.665600</td>
      <td>0.7119</td>
      <td>0.2654</td>
      <td>0.460100</td>
      <td>0.11890</td>
      <td>3.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>842517</td>
      <td>N</td>
      <td>116</td>
      <td>21.37</td>
      <td>17.440000</td>
      <td>137.50</td>
      <td>1373.0</td>
      <td>0.088360</td>
      <td>0.118900</td>
      <td>0.1255</td>
      <td>...</td>
      <td>159.10</td>
      <td>1949.0</td>
      <td>0.118800</td>
      <td>0.344900</td>
      <td>0.3414</td>
      <td>0.2032</td>
      <td>0.433400</td>
      <td>0.09067</td>
      <td>2.5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>843483</td>
      <td>N</td>
      <td>123</td>
      <td>11.42</td>
      <td>20.380000</td>
      <td>77.58</td>
      <td>386.1</td>
      <td>0.102774</td>
      <td>0.142642</td>
      <td>0.2414</td>
      <td>...</td>
      <td>98.87</td>
      <td>567.7</td>
      <td>0.143921</td>
      <td>0.364567</td>
      <td>0.6869</td>
      <td>0.2575</td>
      <td>0.322251</td>
      <td>0.17300</td>
      <td>2.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>843584</td>
      <td>R</td>
      <td>27</td>
      <td>20.29</td>
      <td>14.340000</td>
      <td>135.10</td>
      <td>1297.0</td>
      <td>0.100300</td>
      <td>0.132800</td>
      <td>0.1980</td>
      <td>...</td>
      <td>152.20</td>
      <td>1575.0</td>
      <td>0.137400</td>
      <td>0.205000</td>
      <td>0.4000</td>
      <td>0.1625</td>
      <td>0.236400</td>
      <td>0.07678</td>
      <td>3.5</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 35 columns</p>
</div>




```python
#查看标签
col=data.columns
print(col)
```

    Index(['id', 'outcome', 'time', 'radius_mean', 'texture_mean',
           'perimeter_mean', 'area_mean', 'smoothness_mean', 'compactness_mean',
           'concavity_mean', 'concave points_mean', 'symmetry_mean',
           'fractal_dimension_mean', 'radius_se', 'texture_se', 'perimeter_se',
           'area_se', 'smoothness_se', 'compactness_se', 'concavity_se',
           'concave points_se', 'symmetry_se', 'fractal_dimension_se',
           'radius_worst', 'texture_worst', 'perimeter_worst', 'area_worst',
           'smoothness_worst', 'compactness_worst', 'concavity_worst',
           'concave points_worst', 'symmetry_worst', 'fractal_dimension_worst',
           'diameter of the excised tumor in centimeters', 'Lymph node status'],
          dtype='object')
    


```python
#提取想要分析的结果
y=data.outcome
x=data.drop(['id','outcome','time'],axis = 1)
x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>radius_mean</th>
      <th>texture_mean</th>
      <th>perimeter_mean</th>
      <th>area_mean</th>
      <th>smoothness_mean</th>
      <th>compactness_mean</th>
      <th>concavity_mean</th>
      <th>concave points_mean</th>
      <th>symmetry_mean</th>
      <th>fractal_dimension_mean</th>
      <th>...</th>
      <th>perimeter_worst</th>
      <th>area_worst</th>
      <th>smoothness_worst</th>
      <th>compactness_worst</th>
      <th>concavity_worst</th>
      <th>concave points_worst</th>
      <th>symmetry_worst</th>
      <th>fractal_dimension_worst</th>
      <th>diameter of the excised tumor in centimeters</th>
      <th>Lymph node status</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18.02</td>
      <td>27.600000</td>
      <td>117.50</td>
      <td>1013.0</td>
      <td>0.094890</td>
      <td>0.103600</td>
      <td>0.1086</td>
      <td>0.07055</td>
      <td>0.1865</td>
      <td>0.063330</td>
      <td>...</td>
      <td>139.70</td>
      <td>1436.0</td>
      <td>0.119500</td>
      <td>0.192600</td>
      <td>0.3140</td>
      <td>0.1170</td>
      <td>0.267700</td>
      <td>0.08113</td>
      <td>5.0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>17.99</td>
      <td>22.300979</td>
      <td>122.80</td>
      <td>1001.0</td>
      <td>0.118400</td>
      <td>0.142642</td>
      <td>0.3001</td>
      <td>0.14710</td>
      <td>0.2419</td>
      <td>0.078710</td>
      <td>...</td>
      <td>184.60</td>
      <td>2019.0</td>
      <td>0.162200</td>
      <td>0.665600</td>
      <td>0.7119</td>
      <td>0.2654</td>
      <td>0.460100</td>
      <td>0.11890</td>
      <td>3.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>21.37</td>
      <td>17.440000</td>
      <td>137.50</td>
      <td>1373.0</td>
      <td>0.088360</td>
      <td>0.118900</td>
      <td>0.1255</td>
      <td>0.08180</td>
      <td>0.2333</td>
      <td>0.060100</td>
      <td>...</td>
      <td>159.10</td>
      <td>1949.0</td>
      <td>0.118800</td>
      <td>0.344900</td>
      <td>0.3414</td>
      <td>0.2032</td>
      <td>0.433400</td>
      <td>0.09067</td>
      <td>2.5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.42</td>
      <td>20.380000</td>
      <td>77.58</td>
      <td>386.1</td>
      <td>0.102774</td>
      <td>0.142642</td>
      <td>0.2414</td>
      <td>0.10520</td>
      <td>0.2597</td>
      <td>0.062743</td>
      <td>...</td>
      <td>98.87</td>
      <td>567.7</td>
      <td>0.143921</td>
      <td>0.364567</td>
      <td>0.6869</td>
      <td>0.2575</td>
      <td>0.322251</td>
      <td>0.17300</td>
      <td>2.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20.29</td>
      <td>14.340000</td>
      <td>135.10</td>
      <td>1297.0</td>
      <td>0.100300</td>
      <td>0.132800</td>
      <td>0.1980</td>
      <td>0.10430</td>
      <td>0.1809</td>
      <td>0.058830</td>
      <td>...</td>
      <td>152.20</td>
      <td>1575.0</td>
      <td>0.137400</td>
      <td>0.205000</td>
      <td>0.4000</td>
      <td>0.1625</td>
      <td>0.236400</td>
      <td>0.07678</td>
      <td>3.5</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 32 columns</p>
</div>




```python
#对数据进行描述性统计分析
ax=sns.countplot(y,label="Count")
N,R=y.value_counts()
print('Number of recur',R)
print('Number of nonrecur：', N)
```

    Number of recur 46
    Number of nonrecur： 148
    


![png](output_4_1.png)



```python
#进行描述性数值分析
des=x.describe()
```


```python
#绘制相似性热力图

feature_mean=list(data.columns[2:12])
feature_se=list(data.columns[12:22])
feature_worst=list(data.columns[22:32])
feature_other=list(data.columns[32:34])
corr=data[feature_mean].corr()
plt.figure(figsize=(14,14))
sns.heatmap(corr,annot=True)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26a5d0e56d8>




![png](output_6_1.png)



```python
#数据可视化
#绘制对比分析统计图
data_dia=y
data=x
data_n_2=(data-data.mean())/(data.std())#标准化
data=pd.concat([y,data_n_2.iloc[:,0:10]],axis=1)
data=pd.melt(data,id_vars='outcome',
            var_name='features',
            value_name='value')
plt.figure(figsize=(10,10))
sns.violinplot(x='features',y='value',hue='outcome',data=data,split=True,inner='quart')
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), <a list of 10 Text xticklabel objects>)




![png](output_7_1.png)



```python
#绘制箱线图
plt.figure(figsize=(10,10))
sns.boxplot(x='features',y='value',hue='outcome',data=data)
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), <a list of 10 Text xticklabel objects>)




![png](output_8_1.png)



```python
data_dia=y
data=x
data_n_2=(data-data.mean())/(data.std())#标准化
data=pd.concat([y,data_n_2.iloc[:,10:20]],axis=1)
data=pd.melt(data,id_vars='outcome',
            var_name='features',
            value_name='value')
plt.figure(figsize=(10,10))
sns.violinplot(x='features',y='value',hue='outcome',data=data,split=True,inner='quart')
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), <a list of 10 Text xticklabel objects>)




![png](output_9_1.png)



```python
#绘制箱线图
plt.figure(figsize=(10,10))
sns.boxplot(x='features',y='value',hue='outcome',data=data)
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), <a list of 10 Text xticklabel objects>)




![png](output_10_1.png)



```python
data_dia=y
data=x
data_n_2=(data-data.mean())/(data.std())#标准化
data=pd.concat([y,data_n_2.iloc[:,20:30]],axis=1)
data=pd.melt(data,id_vars='outcome',
            var_name='features',
            value_name='value')
plt.figure(figsize=(10,10))
sns.violinplot(x='features',y='value',hue='outcome',data=data,split=True,inner='quart')
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), <a list of 10 Text xticklabel objects>)




![png](output_11_1.png)



```python
#绘制箱线图
plt.figure(figsize=(10,10))
sns.boxplot(x='features',y='value',hue='outcome',data=data)
plt.xticks(rotation=90)
```




    (array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), <a list of 10 Text xticklabel objects>)




![png](output_12_1.png)



```python
data_dia=y
data=x
data_n_2=(data-data.mean())/(data.std())#标准化
data=pd.concat([y,data_n_2.iloc[:,30:32]],axis=1)
data=pd.melt(data,id_vars='outcome',
            var_name='features',
            value_name='value')
plt.figure(figsize=(10,10))
sns.violinplot(x='features',y='value',hue='outcome',data=data,split=True,inner='quart')
plt.xticks(rotation=90)
```




    (array([0, 1]), <a list of 2 Text xticklabel objects>)




![png](output_13_1.png)



```python
#绘制箱线图
plt.figure(figsize=(10,10))
sns.boxplot(x='features',y='value',hue='outcome',data=data)
plt.xticks(rotation=90)
```




    (array([0, 1]), <a list of 2 Text xticklabel objects>)




![png](output_14_1.png)

